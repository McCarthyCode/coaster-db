-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: coasters
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coasters`
--

DROP TABLE IF EXISTS `coasters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coasters` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `park_id` int(6) unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `track_type` varchar(80) DEFAULT NULL,
  `status` varchar(80) DEFAULT NULL,
  `URL` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coasters`
--

LOCK TABLES `coasters` WRITE;
/*!40000 ALTER TABLE `coasters` DISABLE KEYS */;
INSERT INTO `coasters` VALUES (1,1,'Millenium Force','Steel','Operating',NULL),(2,1,'Maverick','Steel','Operating',NULL),(3,1,'Top Thrill Dragster','Steel','Operating',NULL),(4,1,'Raptor','Steel','Operating',NULL),(5,1,'Mantis','Steel','Retired',NULL),(6,1,'Blue Streak','Wood','Operating',NULL),(7,1,'Mean Streak','Wood','Operating',NULL),(8,1,'Cedar Creek Mine Ride','Steel','Operating',NULL),(9,1,'GateKeeper','Steel','Operating',NULL),(10,1,'Corkscrew','Steel','Operating',NULL),(11,1,'Gemini (Track 1)','Steel','Operating',NULL),(12,1,'Gemini (Track 2)','Steel','Operating',NULL),(13,1,'Iron Dragon','Steel','Operating',NULL),(14,1,'Magnum XL-200','Steel','Operating',NULL),(15,1,'Rougarou','Steel','Operating',NULL),(16,1,'Valravn','Steel','Operating',NULL),(17,1,'Wicked Twister','Steel','Operating',NULL),(18,1,'Wilderness Run','Steel','Operating',NULL),(19,1,'Woodstock Express','Steel','Operating',NULL),(20,2,'Thunderbird','Steel','Operating',NULL),(21,2,'Voyage','Wood','Operating',NULL),(22,2,'Howler','Steel','Operating',NULL),(23,2,'Legend','Wood','Operating',NULL),(24,2,'Raven','Wood','Operating',NULL);
/*!40000 ALTER TABLE `coasters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parks`
--

DROP TABLE IF EXISTS `parks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parks` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `city` varchar(80) DEFAULT NULL,
  `region` varchar(80) DEFAULT NULL,
  `country` varchar(80) DEFAULT NULL,
  `URL` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parks`
--

LOCK TABLES `parks` WRITE;
/*!40000 ALTER TABLE `parks` DISABLE KEYS */;
INSERT INTO `parks` VALUES (1,'Cedar Point','Sandusky','Ohio','USA',NULL),(2,'Holiday World','Santa Claus','Indiana','USA',NULL);
/*!40000 ALTER TABLE `parks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-25 20:32:50
